﻿namespace CodeChum
{
    partial class PotionBrewing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            checkBox3 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox1 = new CheckBox();
            groupBox2 = new GroupBox();
            checkBox6 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox4 = new CheckBox();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton3 = new RadioButton();
            groupBox3 = new GroupBox();
            textBox1 = new TextBox();
            label1 = new Label();
            concoctButton = new Button();
            label2 = new Label();
            descriptionLabel = new Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(checkBox3);
            groupBox1.Controls.Add(checkBox2);
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Location = new Point(49, 93);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(214, 172);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Base Ingredients";
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            checkBox3.Location = new Point(33, 94);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(117, 24);
            checkBox3.TabIndex = 2;
            checkBox3.Text = "Dragon Scale";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            checkBox2.Location = new Point(33, 64);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(152, 24);
            checkBox2.TabIndex = 1;
            checkBox2.Text = "Moonlight Essence";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            checkBox1.Location = new Point(33, 34);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(92, 24);
            checkBox1.TabIndex = 0;
            checkBox1.Text = "Fairy Dust";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(checkBox6);
            groupBox2.Controls.Add(checkBox5);
            groupBox2.Controls.Add(checkBox4);
            groupBox2.Location = new Point(301, 93);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(214, 172);
            groupBox2.TabIndex = 2;
            groupBox2.TabStop = false;
            groupBox2.Text = "Enhancements";
            // 
            // checkBox6
            // 
            checkBox6.AutoSize = true;
            checkBox6.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            checkBox6.Location = new Point(33, 94);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(139, 24);
            checkBox6.TabIndex = 3;
            checkBox6.Text = "Shadowy Secrets";
            checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            checkBox5.Location = new Point(33, 64);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(95, 24);
            checkBox5.TabIndex = 2;
            checkBox5.Text = "Fae Favors";
            checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            checkBox4.AutoSize = true;
            checkBox4.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            checkBox4.Location = new Point(33, 34);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(162, 24);
            checkBox4.TabIndex = 1;
            checkBox4.Text = "Whispers of Wonder";
            checkBox4.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton1.Location = new Point(31, 28);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(89, 24);
            radioButton1.TabIndex = 3;
            radioButton1.TabStop = true;
            radioButton1.Text = "Strengths";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton2.Location = new Point(31, 53);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(92, 24);
            radioButton2.TabIndex = 4;
            radioButton2.TabStop = true;
            radioButton2.Text = "Durability";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            radioButton3.Location = new Point(31, 78);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(70, 24);
            radioButton3.TabIndex = 5;
            radioButton3.TabStop = true;
            radioButton3.Text = "Agility";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(radioButton3);
            groupBox3.Controls.Add(radioButton2);
            groupBox3.Controls.Add(radioButton1);
            groupBox3.Location = new Point(563, 93);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(165, 172);
            groupBox3.TabIndex = 6;
            groupBox3.TabStop = false;
            groupBox3.Text = "Potion Effects";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(191, 301);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(419, 23);
            textBox1.TabIndex = 7;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(191, 283);
            label1.Name = "label1";
            label1.Size = new Size(98, 20);
            label1.TabIndex = 8;
            label1.Text = "Potion Name:";
            // 
            // concoctButton
            // 
            concoctButton.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            concoctButton.Location = new Point(352, 346);
            concoctButton.Name = "concoctButton";
            concoctButton.Size = new Size(89, 34);
            concoctButton.TabIndex = 10;
            concoctButton.Text = "Concoct";
            concoctButton.UseVisualStyleBackColor = true;
            concoctButton.Click += btnConcoct_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(191, 420);
            label2.Name = "label2";
            label2.Size = new Size(167, 20);
            label2.TabIndex = 11;
            label2.Text = "Your Potion Description:";
            // 
            // labelDescription
            // 
            descriptionLabel.AutoSize = true;
            descriptionLabel.Font = new Font("Segoe UI", 11F, FontStyle.Regular, GraphicsUnit.Point);
            descriptionLabel.Location = new Point(199, 455);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new Size(0, 20);
            descriptionLabel.TabIndex = 12;
            // 
            // PotionBrewing
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 606);
            Controls.Add(descriptionLabel);
            Controls.Add(label2);
            Controls.Add(concoctButton);
            Controls.Add(label1);
            Controls.Add(textBox1);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "PotionBrewing";
            Text = "PotionBrewing";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private RadioButton radioButton3;
        private GroupBox groupBox3;
        private TextBox textBox1;
        private Label label1;
        private Button concoctButton;
        private Label label2;
        private Label descriptionLabel;
        private CheckBox checkBox1;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox6;
        private CheckBox checkBox5;
        private CheckBox checkBox4;
    }
}