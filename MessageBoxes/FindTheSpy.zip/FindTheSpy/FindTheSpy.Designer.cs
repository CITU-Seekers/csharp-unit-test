﻿namespace CodeChum
{
    partial class FindTheSpy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstButton = new System.Windows.Forms.Button();
            this.thirdButton = new System.Windows.Forms.Button();
            this.fifthButton = new System.Windows.Forms.Button();
            this.seventhButton = new System.Windows.Forms.Button();
            this.ninthButton = new System.Windows.Forms.Button();
            this.tenthButton = new System.Windows.Forms.Button();
            this.eighthButton = new System.Windows.Forms.Button();
            this.sixthButton = new System.Windows.Forms.Button();
            this.fourthButton = new System.Windows.Forms.Button();
            this.secondButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // firstButton
            // 
            this.firstButton.Location = new System.Drawing.Point(33, 32);
            this.firstButton.Name = "firstButton";
            this.firstButton.Size = new System.Drawing.Size(84, 25);
            this.firstButton.TabIndex = 0;
            this.firstButton.Text = "2156";
            this.firstButton.UseVisualStyleBackColor = true;
            this.firstButton.Click += new System.EventHandler(this.FirstButton_Click);
            // 
            // thirdButton
            // 
            this.thirdButton.Location = new System.Drawing.Point(241, 32);
            this.thirdButton.Name = "thirdButton";
            this.thirdButton.Size = new System.Drawing.Size(84, 25);
            this.thirdButton.TabIndex = 1;
            this.thirdButton.Text = "124";
            this.thirdButton.UseVisualStyleBackColor = true;
            this.thirdButton.Click += new System.EventHandler(this.ThirdButton_Click);
            // 
            // fifthButton
            // 
            this.fifthButton.Location = new System.Drawing.Point(448, 32);
            this.fifthButton.Name = "fifthButton";
            this.fifthButton.Size = new System.Drawing.Size(84, 25);
            this.fifthButton.TabIndex = 2;
            this.fifthButton.Text = "1214";
            this.fifthButton.UseVisualStyleBackColor = true;
            this.fifthButton.Click += new System.EventHandler(this.FifthButton_Click);
            // 
            // seventhButton
            // 
            this.seventhButton.Location = new System.Drawing.Point(139, 76);
            this.seventhButton.Name = "seventhButton";
            this.seventhButton.Size = new System.Drawing.Size(84, 25);
            this.seventhButton.TabIndex = 3;
            this.seventhButton.Text = "11";
            this.seventhButton.UseVisualStyleBackColor = true;
            this.seventhButton.Click += new System.EventHandler(this.SeventhButton_Click);
            // 
            // ninthButton
            // 
            this.ninthButton.Location = new System.Drawing.Point(345, 76);
            this.ninthButton.Name = "ninthButton";
            this.ninthButton.Size = new System.Drawing.Size(84, 25);
            this.ninthButton.TabIndex = 4;
            this.ninthButton.Text = "213";
            this.ninthButton.UseVisualStyleBackColor = true;
            this.ninthButton.Click += new System.EventHandler(this.NinthButton_Click);
            // 
            // tenthButton
            // 
            this.tenthButton.Location = new System.Drawing.Point(448, 76);
            this.tenthButton.Name = "tenthButton";
            this.tenthButton.Size = new System.Drawing.Size(84, 25);
            this.tenthButton.TabIndex = 9;
            this.tenthButton.Text = "54136";
            this.tenthButton.UseVisualStyleBackColor = true;
            this.tenthButton.Click += new System.EventHandler(this.TenthButton_Click);
            // 
            // eighthButton
            // 
            this.eighthButton.Location = new System.Drawing.Point(241, 76);
            this.eighthButton.Name = "eighthButton";
            this.eighthButton.Size = new System.Drawing.Size(84, 25);
            this.eighthButton.TabIndex = 8;
            this.eighthButton.Text = "22";
            this.eighthButton.UseVisualStyleBackColor = true;
            this.eighthButton.Click += new System.EventHandler(this.EighthButton_Click);
            // 
            // sixthButton
            // 
            this.sixthButton.Location = new System.Drawing.Point(33, 76);
            this.sixthButton.Name = "sixthButton";
            this.sixthButton.Size = new System.Drawing.Size(84, 25);
            this.sixthButton.TabIndex = 7;
            this.sixthButton.Text = "562";
            this.sixthButton.UseVisualStyleBackColor = true;
            this.sixthButton.Click += new System.EventHandler(this.SixthButton_Click);
            // 
            // fourthButton
            // 
            this.fourthButton.Location = new System.Drawing.Point(345, 32);
            this.fourthButton.Name = "fourthButton";
            this.fourthButton.Size = new System.Drawing.Size(84, 25);
            this.fourthButton.TabIndex = 6;
            this.fourthButton.Text = "2014";
            this.fourthButton.UseVisualStyleBackColor = true;
            this.fourthButton.Click += new System.EventHandler(this.FourthButton_Click);
            // 
            // secondButton
            // 
            this.secondButton.Location = new System.Drawing.Point(139, 32);
            this.secondButton.Name = "secondButton";
            this.secondButton.Size = new System.Drawing.Size(84, 25);
            this.secondButton.TabIndex = 5;
            this.secondButton.Text = "2265";
            this.secondButton.UseVisualStyleBackColor = true;
            this.secondButton.Click += new System.EventHandler(this.SecondButton_Click);
            // 
            // FindTheSpy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(556, 123);
            this.Controls.Add(this.tenthButton);
            this.Controls.Add(this.eighthButton);
            this.Controls.Add(this.sixthButton);
            this.Controls.Add(this.fourthButton);
            this.Controls.Add(this.secondButton);
            this.Controls.Add(this.ninthButton);
            this.Controls.Add(this.seventhButton);
            this.Controls.Add(this.fifthButton);
            this.Controls.Add(this.thirdButton);
            this.Controls.Add(this.firstButton);
            this.Name = "FindTheSpy";
            this.Text = "FindTheSpy";
            this.ResumeLayout(false);

        }

        #endregion

        private Button firstButton;
        private Button thirdButton;
        private Button fifthButton;
        private Button seventhButton;
        private Button ninthButton;
        private Button tenthButton;
        private Button eighthButton;
        private Button sixthButton;
        private Button fourthButton;
        private Button secondButton;
    }
}